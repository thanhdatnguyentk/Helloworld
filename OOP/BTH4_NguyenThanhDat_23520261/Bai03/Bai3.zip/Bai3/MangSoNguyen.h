#include <bits/stdc++.h>
#include<iostream>
using namespace std;
bool check(string s);
class MangSoNguyen
{
private:
    int* duLieu;
    int kichthuoc;
public:
    MangSoNguyen() : duLieu(nullptr), kichthuoc(0) {}
    MangSoNguyen(int size) : kichthuoc(size) {
        duLieu = new int[size];
    }
    ~MangSoNguyen() {
        delete[] duLieu;
    }
    MangSoNguyen& operator=(const MangSoNguyen& other) {
        if (this != &other) {
            delete[] duLieu;
            kichthuoc = other.kichthuoc;
            duLieu = new int[kichthuoc];
            for (int i = 0; i < kichthuoc; ++i) {
                duLieu[i] = other.duLieu[i];
            }
        }
        return *this;
    }
    MangSoNguyen operator+(const MangSoNguyen& other) const {
        int newSize = std::max(kichthuoc, other.kichthuoc);
        MangSoNguyen result(newSize);
        for (int i = 0; i < newSize; ++i) {
            result.duLieu[i] = duLieu[i] + other.duLieu[i];
        }
        return result;
    }
    MangSoNguyen& operator++() {
        for (int i = 0; i < kichthuoc; ++i) {
            ++duLieu[i];
        }
        return *this;
    }
    // Toán tử nhập
    friend std::istream& operator>>(std::istream& is, MangSoNguyen& arr) {
        for (int i = 0; i < arr.kichthuoc; ++i) {
            is >> arr.duLieu[i];
        }
        return is;
    }
    friend std::ostream& operator<<(std::ostream& os, const MangSoNguyen& arr) {
        for (int i = 0; i < arr.kichthuoc; ++i) {
            os << arr.duLieu[i] << " ";
        }
        return os;
    }
};
