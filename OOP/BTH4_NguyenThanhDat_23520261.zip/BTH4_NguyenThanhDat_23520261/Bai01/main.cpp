#include"PHANSO.h"

int main(){
    PhanSo a,b;
    cin >> a;
    cin >> b;
    cout << a << endl;
    cout << b << endl;

    PhanSo c = a + b;
    cout << c << endl;

    c = a - b;
    cout << c << endl;
    c = a * b;
    cout << c << endl;
    c = a / b;
    cout << c << endl;
    
}