#include<bits/stdc++.h>
#include"Bai01.h"

using namespace std;

int main(){
    HocSinh a;
    a.Nhap();
    a.Xuat();
}